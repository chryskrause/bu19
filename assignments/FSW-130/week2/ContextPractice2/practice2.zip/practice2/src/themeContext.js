import React, {Component} from "react"

const {Provider, Consumer} = React.createContext()

class ThemeContextProvider extends Component {
    state = {
        animal: "",
    }

    changeAnimal = (animal) => {
        this.setState({animal})
    }

    render(){
        const {animal} = this.state
        return(
            <Provider value={{animal, changeAnimal: this.changeAnimal}}>
                {this.props.children}
            </Provider>

        )
    }
}

export {ThemeContextProvider, Consumer as ThemeContextConsumer}