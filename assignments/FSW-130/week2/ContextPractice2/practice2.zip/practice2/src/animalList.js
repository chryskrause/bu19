const animalList = [
    {
        id: 1,
        name: "Elephants",
        imageURL: "https://images.unsplash.com/photo-1578326626553-39f72c545b07?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=729&q=80",
    },{
        id: 2,
        name: "Penguins",
        imageURL: "https://images.unsplash.com/photo-1574950333594-f3e9a9446d0f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
    },{
        id: 3,
        name: "Giraffe",
        imageURL: "https://images.unsplash.com/photo-1574870111867-089730e5a72b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80",
    },{
        id: 4,
        name: "Horse",
        imageURL: "https://images.unsplash.com/photo-1470422862902-688c1ae73e86?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1866&q=80",
    },{
        id: 5, 
        name: "Owl",
        imageURL: "https://images.unsplash.com/photo-1555677284-6a6f971638e0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80",
    }
]

export default animalList